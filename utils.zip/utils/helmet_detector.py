
from ultralytics import YOLO

model = YOLO("models/helmet.pt")

def detect_helmet(frame):

    results = model(frame)

    detections = []

    for r in results:
        for box in r.boxes:

            x1,y1,x2,y2 = map(int, box.xyxy[0])
            cls = int(box.cls[0])
            label = model.names[cls]

            detections.append((x1,y1,x2,y2,label))

    return detections
